self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3d7a6bfb6d5f608bc289",
    "url": "/assets/app/css/app.53a8c2ec.css"
  },
  {
    "revision": "d6cf7b0922ccebecc3c2",
    "url": "/assets/app/css/chunk-vendors.49bf0263.css"
  },
  {
    "revision": "a4cba1f9d0a81335d8ae",
    "url": "/assets/app/css/demo.5ed8764d.css"
  },
  {
    "revision": "cb47f9e4f68a14762e4a",
    "url": "/assets/app/css/demo~login~register.0670aa22.css"
  },
  {
    "revision": "dbf809692c5195f95bc2",
    "url": "/assets/app/css/login.5c9cff5e.css"
  },
  {
    "revision": "d8a8645436d75701022f",
    "url": "/assets/app/css/login~register.c0df4ef6.css"
  },
  {
    "revision": "f477127d725a18988ea6",
    "url": "/assets/app/css/register.30e99c35.css"
  },
  {
    "revision": "05727d32400b2008acbf7fc49251ede0",
    "url": "/assets/app/fonts/Yekan.05727d32.woff"
  },
  {
    "revision": "1008c3b88ceb6f09efbf88dafa3e9d91",
    "url": "/assets/app/fonts/Yekan.1008c3b8.ttf"
  },
  {
    "revision": "bc6d90407f63fc592ca820798c91540d",
    "url": "/assets/app/img/background.bc6d9040.jpg"
  },
  {
    "revision": "bc6d90407f63fc592ca820798c91540d",
    "url": "/assets/app/img/background.jpg"
  },
  {
    "revision": "b1dad43ec5ade013eb3301d1c7a85e62",
    "url": "/assets/app/img/graph.png"
  },
  {
    "revision": "ce25301a6e42dfb04bc931d7918c04ad",
    "url": "/assets/app/img/line-graph.png"
  },
  {
    "revision": "b51fb8ec42a4d82872297762192b4a87",
    "url": "/assets/app/img/logo-for-splash-screen.png"
  },
  {
    "revision": "91b6094f5f0b39ffe5311ee8d835946c",
    "url": "/assets/app/img/logo.png"
  },
  {
    "revision": "5a0e5f2493f5cb0aa0961cff15578ee9",
    "url": "/assets/app/img/logout.png"
  },
  {
    "revision": "d3b5bdaf703aada3e332bc090632454f",
    "url": "/assets/app/img/man-user.png"
  },
  {
    "revision": "5ece63fb06fe7d0b5e2770d5a9b6b8d1",
    "url": "/assets/app/img/money-growth.png"
  },
  {
    "revision": "b72f93928fcc3c4ce0c26204f25fbd0f",
    "url": "/assets/app/img/statistics.png"
  },
  {
    "revision": "5576162976bf784c6cc52b1951197cca",
    "url": "/assets/app/index.html"
  },
  {
    "revision": "3d7a6bfb6d5f608bc289",
    "url": "/assets/app/js/app.153bbe96.js"
  },
  {
    "revision": "d6cf7b0922ccebecc3c2",
    "url": "/assets/app/js/chunk-vendors.0e108006.js"
  },
  {
    "revision": "a4cba1f9d0a81335d8ae",
    "url": "/assets/app/js/demo.82d0c22b.js"
  },
  {
    "revision": "cb47f9e4f68a14762e4a",
    "url": "/assets/app/js/demo~login~register.f529b0f0.js"
  },
  {
    "revision": "dbf809692c5195f95bc2",
    "url": "/assets/app/js/login.9d955959.js"
  },
  {
    "revision": "d8a8645436d75701022f",
    "url": "/assets/app/js/login~register.d9a74b1b.js"
  },
  {
    "revision": "f477127d725a18988ea6",
    "url": "/assets/app/js/register.8fd5372a.js"
  },
  {
    "revision": "44378da48df29937591d2d0629f64733",
    "url": "/assets/app/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/assets/app/robots.txt"
  }
]);