self.__precacheManifest = [
  {
    "revision": "50dd5fdc839dfc16739b15370650485c",
    "url": "/assets/admin/img/theme/react.jpg"
  },
  {
    "revision": "cee60cfd101f9b3d2aae0e819ec8b267",
    "url": "/assets/admin/img/theme/profile-cover.jpg"
  },
  {
    "revision": "c9bd86575fd1aebfa9d1",
    "url": "/assets/admin/js/chunk-vendors.55ab79d1.js"
  },
  {
    "revision": "be997d5226b992ffad34816870c6b7aa",
    "url": "/assets/admin/img/theme/team-2-800x800.jpg"
  },
  {
    "revision": "85fde6d1216b72017255",
    "url": "/assets/admin/js/demo.13174254.js"
  },
  {
    "revision": "54e3f3c414bd8e7234bae3ee3be950e5",
    "url": "/assets/admin/img/theme/team-3-800x800.jpg"
  },
  {
    "revision": "edc7106b21ec12e57022b2ebd534cd2d",
    "url": "/assets/admin/img/theme/team-1-800x800.jpg"
  },
  {
    "revision": "66618a418175ddf2ac8c47a241d327a8",
    "url": "/assets/admin/img/theme/team-4-800x800.jpg"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/assets/admin/robots.txt"
  },
  {
    "revision": "c532f6f0176968caa6265864ee1abb35",
    "url": "/assets/admin/img/theme/vue.jpg"
  },
  {
    "revision": "2fa20c3f61d375e26b15e8522046a5c1",
    "url": "/assets/admin/img/theme/user-avatar.png"
  },
  {
    "revision": "3b8c576082e5ca27bae21a839f1290f6",
    "url": "/assets/admin/img/theme/sketch.jpg"
  },
  {
    "revision": "a6b4d061c683c9d685f2c7f420912741",
    "url": "/assets/admin/index.html"
  },
  {
    "revision": "4265d75123e02fc39c75",
    "url": "/assets/admin/js/app.3ddf5efc.js"
  },
  {
    "revision": "c2abf74025339d951357dc880006ab71",
    "url": "/assets/admin/img/brand/sample-logo.png"
  },
  {
    "revision": "e0ea3f1916671872498288dc2bd40f06",
    "url": "/assets/admin/img/brand/white.png"
  },
  {
    "revision": "d136a071cf09ba5ab8dc2ada1ab04015",
    "url": "/assets/admin/img/theme/bootstrap.jpg"
  },
  {
    "revision": "11a6650494094769129c811f43042836",
    "url": "/assets/admin/img/logos/ethereum-eth-logo.png"
  },
  {
    "revision": "ef19606437a24b1d9e3e244939f76fdc",
    "url": "/assets/admin/img/logos/bitcoin-btc-logo.png"
  },
  {
    "revision": "cc2cf09367527bb93e74a48002f3db55",
    "url": "/assets/admin/img/logos/litecoin-ltc-logo.png"
  },
  {
    "revision": "46abbc4a676739dbd61f8a305cb63fd8",
    "url": "/assets/admin/img/nucleo-icons.46abbc4a.svg"
  },
  {
    "revision": "39cdeae91450f4c2f6d735e05c6a7ad3",
    "url": "/assets/admin/img/logos/monero-xmr-logo.png"
  },
  {
    "revision": "1f533d2fdc40493ee834dd8e4288220c",
    "url": "/assets/admin/img/theme/angular.jpg"
  },
  {
    "revision": "111222f9c8bf556ea3169c42d078d72f",
    "url": "/assets/admin/img/logos/webmoney_logo.png"
  },
  {
    "revision": "59d7c2b119ab46fc7b5f853f04324c89",
    "url": "/assets/admin/img/brand/green.png"
  },
  {
    "revision": "a794a15f6e45b941d8a521e7965221a8",
    "url": "/assets/admin/img/brand/favicon.png"
  },
  {
    "revision": "f82ec6ba2dc4181db2af35c499462840",
    "url": "/assets/admin/fonts/nucleo-icons.f82ec6ba.ttf"
  },
  {
    "revision": "c1733565b32b585676302d4233c39da8",
    "url": "/assets/admin/fonts/nucleo-icons.c1733565.eot"
  },
  {
    "revision": "426439788ec5ba772cdf94057f6f4659",
    "url": "/assets/admin/fonts/nucleo-icons.42643978.woff2"
  },
  {
    "revision": "2569aaea6eaaf8cd210db7f2fa016743",
    "url": "/assets/admin/fonts/nucleo-icons.2569aaea.woff"
  },
  {
    "revision": "1008c3b88ceb6f09efbf88dafa3e9d91",
    "url": "/assets/admin/fonts/Yekan.1008c3b8.ttf"
  },
  {
    "revision": "05727d32400b2008acbf7fc49251ede0",
    "url": "/assets/admin/fonts/Yekan.05727d32.woff"
  },
  {
    "revision": "85fde6d1216b72017255",
    "url": "/assets/admin/css/demo.41def942.css"
  },
  {
    "revision": "4265d75123e02fc39c75",
    "url": "/assets/admin/css/app.4edd4419.css"
  }
];